package Modelo;

import java.sql.*;
import Modelo.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

import vista.Vendedore;

public class ModeloLogin extends Conexion {

    public boolean ValidaUsuario(UsuarioDAO vendedor) {
            PreparedStatement ps = null;
        ResultSet rs = null;
        Connection Conexion = getConnection();
              try {
             Connection conexion = getConnection();
            PreparedStatement pst =conexion.prepareStatement("SELECT id usuario, contraseña, nombre,id_tipo   FROM vendedores WHERE usuario=?");
            pst.setString(1, vendedor.getUsuario());
            rs= pst.executeQuery();

            if (rs.next()) {
                if (vendedor.getContraseña().equals(rs.getString("contraseña"))) {
                    vendedor.setNombre((String) rs.getString("nombre"));
                    vendedor.setId_tipo(rs.getInt("id_tipo"));
                   
                   return true;
                }
            } else {
                return false;
            }

        } catch (SQLException e) {
            System.err.println("Error en el ModeloLogin " + e);
             
        }
        return false;
    
        
    }

    public boolean registra(UsuarioDAO Vendedor) {
        PreparedStatement ps = null;
        Connection Conexion = getConnection();
        String sql = "INSERT INTO vendedores(usuario,contraseña,nombre,correo,id_tipo)VALUES(?,?,?,?,?)";

        try {
            ps = Conexion.prepareStatement(sql);

            ps.setString(1, Vendedor.getUsuario());
            ps.setString(2, Vendedor.getContraseña());
            ps.setString(3, Vendedor.getNombre());
            ps.setString(4, Vendedor.getCorreo());
            ps.setInt(5, Vendedor.getId_tipo());

            ps.execute();
            return true;
        } catch (SQLException ex) {
        }

        return false;
    }

    public int existeusuario(String Vendedor) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection Conexion = getConnection();
        String sql = "SELECT count(id) FROM  vendedores WHERE usuario=?";

        try {
            ps = Conexion.prepareStatement(sql);

            ps.setString(1, Vendedor);
            rs = ps.executeQuery();
          if(rs.next())
          {
              return rs.getInt(1);
          }
          
          return  1;
        } catch (SQLException ex) {
            return 1;
        }
    }
        
        // PATRON  DE VALIDAR DE EMAIL
    
    public boolean exiscorreo(String correo){
    Pattern pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"+"[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
       
    Matcher mather =pattern.matcher(correo);
    
    return mather.find();
    }

    private Object a() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
       
    
}

package Modelo;

import java.sql.*;
import javax.swing.JOptionPane;

public class Conexion {

      Connection Conexion = null;

    public static final String URL = "jdbc:mysql://localhost:3306/bd";
    public static final String usuario = "root";
    public static final String contraseña = "";

    public static Connection getConnection() {
        Connection Conexion = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Conexion = DriverManager.getConnection(URL, usuario, contraseña);

        } catch (Exception e) {
            System.err.println("e");
        }
        return Conexion;
    }

}

package controlador;

import Modelo.ModeloLogin;
import vista.*;
import Modelo.UsuarioDAO;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class controlLogin {

    //Instancia o copia de la clase VendedorDAO
    public static UsuarioDAO vendedor = new UsuarioDAO();
    public static VistaLogin vistaLogin = new VistaLogin();
    public static ModeloLogin modeloLogin = new ModeloLogin();

    controlLogin(VistaLogin vistaLogin, ModeloLogin modelologin, UsuarioDAO vendedor) {
        this.vendedor = vendedor;
        this.vistaLogin = vistaLogin;
        this.modeloLogin = modelologin;
    }

    public void IniciaSesion() {
        vistaLogin.setTitle("Ingresar al sistema");
        vistaLogin.setLocationRelativeTo(null);
        vistaLogin.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public static void ValidaUsuario() {
        vendedor.setUsuario(vistaLogin.txtUsuario.getText().trim());
        vendedor.setContraseña(vistaLogin.txtContraseña.getText().trim());
         // validar campos vacios 
            
            
        if (vendedor.getUsuario().isEmpty() || vendedor.getContraseña().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debes llenar todos los campo");
        } else {
            if (modeloLogin.ValidaUsuario(vendedor)) {
                
                vistaLogin.setVisible(false);
                //creo un objecto vista menu princpla y el envio el contructor el usuario secion
                VistaMenuPrincipal Vmenu = new 
                 VistaMenuPrincipal(vendedor);
                Vmenu.setVisible(true);

            } else {
                vistaLogin.labelUsuarioContraseñaIncorrecta.setText("Usuario o contraseña incorrecta");
            }
        }
    }
}
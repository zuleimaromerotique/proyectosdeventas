
package controlador;

import Modelo.ModeloLogin;
import Modelo.UsuarioDAO;
import vista.VistaLogin;

public class ControladorPrincipal {
      public static void main(String args[]){
           VistaLogin vistaLogin = new VistaLogin();
        UsuarioDAO vendedor = new UsuarioDAO();
        ModeloLogin modelologin = new ModeloLogin();
        
        controlLogin controlLogin = new 
        controlLogin(vistaLogin,modelologin,vendedor);
        controlLogin.IniciaSesion();
        vistaLogin.setVisible(true);
}
}

                
package vista;

import Modelo.Conexion;
import com.mysql.jdbc.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.sql.*;
import javax.swing.WindowConstants;

public class VistaProveedores extends javax.swing.JFrame {

    PreparedStatement ps;
    ResultSet rs;

    Connection Conexion = null;

    public static final String URL = "jdbc:mysql://localhost:3306/bd";
    public static final String usuario = "root";
    public static final String contraseña = "";

    public static Connection getConnection() {
        Connection Conexion = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Conexion = DriverManager.getConnection(URL, usuario, contraseña);
            

        } catch (Exception e) {
            System.err.println("e");
        }
        return Conexion;
    }

    private void Limpiarcaja() {
        txtNitProvedor1.setText(null);
        txtProveedor.setText(null);
        txtDirreProvedo.setText(null);
        txtCorreoProvedor.setText(null);
        txtTelefonoprove.setText(null);

    }

    public VistaProveedores() {
        initComponents();
         setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
    this.setResizable(false);
         txtId.setVisible(false);


    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnEncabezadoProvedor = new javax.swing.JPanel();
        lbProvedorEncabezado = new javax.swing.JLabel();
        pnProvedores = new javax.swing.JPanel();
        lbCorreoProve = new javax.swing.JLabel();
        lbProvedor = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        txtTelefonoprove = new javax.swing.JTextField();
        lbNitProve = new javax.swing.JLabel();
        txtCorreoProvedor = new javax.swing.JTextField();
        lbTelefonoProve = new javax.swing.JLabel();
        lbDirreProveedor = new javax.swing.JLabel();
        txtProveedor = new javax.swing.JTextField();
        txtDirreProvedo = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbDatoProvedor = new javax.swing.JTable();
        btModificarrovedor = new javax.swing.JButton();
        btBuscarProvedor = new javax.swing.JButton();
        txtNitProvedor1 = new javax.swing.JTextField();
        btGuardarProvedor = new javax.swing.JButton();
        lbDerechoAutor = new javax.swing.JLabel();
        bteliminarProvedor = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnEncabezadoProvedor.setBackground(new java.awt.Color(102, 204, 255));

        lbProvedorEncabezado.setBackground(new java.awt.Color(0, 0, 0));
        lbProvedorEncabezado.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        lbProvedorEncabezado.setForeground(new java.awt.Color(0, 0, 0));
        lbProvedorEncabezado.setText("Proveedores");

        javax.swing.GroupLayout pnEncabezadoProvedorLayout = new javax.swing.GroupLayout(pnEncabezadoProvedor);
        pnEncabezadoProvedor.setLayout(pnEncabezadoProvedorLayout);
        pnEncabezadoProvedorLayout.setHorizontalGroup(
            pnEncabezadoProvedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnEncabezadoProvedorLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbProvedorEncabezado, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnEncabezadoProvedorLayout.setVerticalGroup(
            pnEncabezadoProvedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnEncabezadoProvedorLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbProvedorEncabezado, javax.swing.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnProvedores.setBackground(new java.awt.Color(255, 255, 255));

        lbCorreoProve.setBackground(new java.awt.Color(0, 0, 0));
        lbCorreoProve.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbCorreoProve.setForeground(new java.awt.Color(0, 0, 0));
        lbCorreoProve.setText("Correo");

        lbProvedor.setBackground(new java.awt.Color(0, 0, 0));
        lbProvedor.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbProvedor.setForeground(new java.awt.Color(0, 0, 0));
        lbProvedor.setText("Proveedor");

        txtId.setPreferredSize(new java.awt.Dimension(20, 24));
        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });

        lbNitProve.setBackground(new java.awt.Color(0, 0, 0));
        lbNitProve.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbNitProve.setForeground(new java.awt.Color(0, 0, 0));
        lbNitProve.setText("Nit");

        lbTelefonoProve.setBackground(new java.awt.Color(0, 0, 0));
        lbTelefonoProve.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbTelefonoProve.setForeground(new java.awt.Color(0, 0, 0));
        lbTelefonoProve.setText("Telefono");

        lbDirreProveedor.setBackground(new java.awt.Color(0, 0, 0));
        lbDirreProveedor.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbDirreProveedor.setForeground(new java.awt.Color(0, 0, 0));
        lbDirreProveedor.setText("Dirrecion");

        txtDirreProvedo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDirreProvedoActionPerformed(evt);
            }
        });

        tbDatoProvedor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nit", "Proveedor", "Dirreccion", "Correo", "Telefon"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tbDatoProvedor);

        btModificarrovedor.setText("Modificar");
        btModificarrovedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btModificarrovedorActionPerformed(evt);
            }
        });

        btBuscarProvedor.setText("Buscar");
        btBuscarProvedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btBuscarProvedorActionPerformed(evt);
            }
        });

        txtNitProvedor1.setPreferredSize(new java.awt.Dimension(20, 24));
        txtNitProvedor1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNitProvedor1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnProvedoresLayout = new javax.swing.GroupLayout(pnProvedores);
        pnProvedores.setLayout(pnProvedoresLayout);
        pnProvedoresLayout.setHorizontalGroup(
            pnProvedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnProvedoresLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnProvedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnProvedoresLayout.createSequentialGroup()
                        .addComponent(btBuscarProvedor, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 845, Short.MAX_VALUE)
                    .addGroup(pnProvedoresLayout.createSequentialGroup()
                        .addGroup(pnProvedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(pnProvedoresLayout.createSequentialGroup()
                                .addComponent(lbCorreoProve, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtCorreoProvedor, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnProvedoresLayout.createSequentialGroup()
                                .addGroup(pnProvedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lbNitProve, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lbProvedor, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(pnProvedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pnProvedoresLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(txtProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pnProvedoresLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtNitProvedor1, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)))))
                        .addGroup(pnProvedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnProvedoresLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(pnProvedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lbDirreProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lbTelefonoProve, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(30, 30, 30))
                            .addGroup(pnProvedoresLayout.createSequentialGroup()
                                .addGap(112, 112, 112)
                                .addComponent(btModificarrovedor, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(76, 76, 76)))
                        .addGroup(pnProvedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTelefonoprove, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDirreProvedo, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        pnProvedoresLayout.setVerticalGroup(
            pnProvedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnProvedoresLayout.createSequentialGroup()
                .addComponent(btBuscarProvedor, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnProvedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnProvedoresLayout.createSequentialGroup()
                        .addGroup(pnProvedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbNitProve, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNitProvedor1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnProvedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbProvedor, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(22, 22, 22)
                        .addGroup(pnProvedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbCorreoProve, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCorreoProvedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btModificarrovedor, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20))
                    .addGroup(pnProvedoresLayout.createSequentialGroup()
                        .addGroup(pnProvedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtTelefonoprove)
                            .addComponent(lbTelefonoProve, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(pnProvedoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtDirreProvedo, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbDirreProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE)
                .addContainerGap())
        );

        btGuardarProvedor.setText("Guardar");
        btGuardarProvedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btGuardarProvedorActionPerformed(evt);
            }
        });

        lbDerechoAutor.setText("© Todos los Derechos Reservados 2022");

        bteliminarProvedor.setText("Eliminar");
        bteliminarProvedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bteliminarProvedorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pnEncabezadoProvedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(pnProvedores, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(btGuardarProvedor, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bteliminarProvedor, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31)
                        .addComponent(lbDerechoAutor)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnEncabezadoProvedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnProvedores, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btGuardarProvedor, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bteliminarProvedor, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(lbDerechoAutor)))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed

    private void txtDirreProvedoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDirreProvedoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDirreProvedoActionPerformed

    private void btModificarrovedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btModificarrovedorActionPerformed

        try {

            Conexion = getConnection();
            ps = (PreparedStatement) Conexion.prepareStatement("UPDATE  provedores SET nit=?,nom=?,direcion=?,correo=?,telefono=? WHERE id=?");

            ps.setString(1, txtNitProvedor1.getText());
            ps.setString(2, txtProveedor.getText());
            ps.setString(3, txtDirreProvedo.getText());
            ps.setString(4, txtCorreoProvedor.getText());
            ps.setString(5, txtTelefonoprove.getText());
            ps.setString(6, txtId.getText());

            int res = ps.executeUpdate();
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "Modificado Con Existos");

            } else {
                JOptionPane.showMessageDialog(null, "Error Al Eliminar");

            }
            Conexion.close();
        } catch (Exception e) {
            System.err.println(e);

        }

        // constrctor Guardar Provedor
    }//GEN-LAST:event_btModificarrovedorActionPerformed

    private void btGuardarProvedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btGuardarProvedorActionPerformed


        try {
            Connection cn = getConnection();
            ps = (PreparedStatement) cn.prepareStatement("INSERT INTO  provedores (id,nit,nom,direcion,correo,telefono)VALUES(?,?,?,?,?,?)");
            ps.setInt(1, 0);
            ps.setString(2, txtNitProvedor1.getText());
            ps.setString(3, txtProveedor.getText());
            ps.setString(4, txtDirreProvedo.getText());
            ps.setString(5, txtCorreoProvedor.getText());
            ps.setString(6, txtTelefonoprove.getText());
            int res = ps.executeUpdate();
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "existoso Guardado");
                Limpiarcaja();
            } else {
                JOptionPane.showMessageDialog(null, "Error Al Guardar");
                Limpiarcaja();
            }
            cn.close();
        } catch (Exception e) {
            System.err.println(e);

        }

        // constrctor Buscar Provedor

    }//GEN-LAST:event_btGuardarProvedorActionPerformed

    private void btBuscarProvedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btBuscarProvedorActionPerformed
        Connection Conexion = null;

        try {
            Conexion = getConnection();
            ps = (PreparedStatement) Conexion.prepareStatement("SELECT *FROM provedores WHERE nit=?");
            ps.setString(1, txtNitProvedor1.getText());
            rs = ps.executeQuery();
            if (rs.next()) {

                txtProveedor.setText(rs.getString("nom"));
                txtDirreProvedo.setText(rs.getString("direcion"));
                txtCorreoProvedor.setText(rs.getString("correo"));
                txtTelefonoprove.setText(rs.getString("telefono"));

            } else {
                JOptionPane.showMessageDialog(null, "No se encontro ");

            }
            Conexion.close();
        } catch (Exception e) {
            System.err.println(e);

    }//GEN-LAST:event_btBuscarProvedorActionPerformed
    }
    private void txtNitProvedor1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNitProvedor1ActionPerformed
        // TODO add your handling code here:

        // constrctor Guardar Provedor
    }//GEN-LAST:event_txtNitProvedor1ActionPerformed

    private void bteliminarProvedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bteliminarProvedorActionPerformed
        Connection Conexion = null;
        try {
            Conexion = getConnection();
            ps = (PreparedStatement) Conexion.prepareStatement("DELETE FROM provedores WHERE nit=?");

            ps.setString(1, txtNitProvedor1.getText());
            int res = ps.executeUpdate();

            if (res > 0) {
                JOptionPane.showMessageDialog(null, "Eliminar Producto");
                Limpiarcaja();
            } else {
                JOptionPane.showMessageDialog(null, "Error Al Eliminar ");
                Limpiarcaja();
            }
            Conexion.close();
        } catch (Exception e) {
            System.err.println(e);
        }
    }//GEN-LAST:event_bteliminarProvedorActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VistaProveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VistaProveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VistaProveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VistaProveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VistaProveedores().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btBuscarProvedor;
    public javax.swing.JButton btGuardarProvedor;
    public javax.swing.JButton btModificarrovedor;
    public javax.swing.JButton bteliminarProvedor;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JLabel lbCorreoProve;
    public javax.swing.JLabel lbDerechoAutor;
    public javax.swing.JLabel lbDirreProveedor;
    public javax.swing.JLabel lbNitProve;
    public javax.swing.JLabel lbProvedor;
    public javax.swing.JLabel lbProvedorEncabezado;
    public javax.swing.JLabel lbTelefonoProve;
    public javax.swing.JPanel pnEncabezadoProvedor;
    public javax.swing.JPanel pnProvedores;
    public javax.swing.JTable tbDatoProvedor;
    public javax.swing.JTextField txtCorreoProvedor;
    public javax.swing.JTextField txtDirreProvedo;
    public javax.swing.JTextField txtId;
    public javax.swing.JTextField txtNitProvedor1;
    public javax.swing.JTextField txtProveedor;
    public javax.swing.JTextField txtTelefonoprove;
    // End of variables declaration//GEN-END:variables
}

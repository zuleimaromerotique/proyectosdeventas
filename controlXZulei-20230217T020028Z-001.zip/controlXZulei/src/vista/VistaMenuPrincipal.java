package vista;

import Modelo.Conexion;
import Modelo.UsuarioDAO;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import javax.swing.JOptionPane;





public final class VistaMenuPrincipal extends javax.swing.JFrame {
    
      UsuarioDAO vendedor;
    
       Connection Conexion = null;
    public static final String URL = "jdbc:mysql://localhost:3306/bd";
    public static final String usuario = "root";
    public static final String contraseña = "";

    public static java.sql.Connection getConnection() {
        java.sql.Connection Conexion = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Conexion = DriverManager.getConnection(URL, usuario, contraseña);
            

        } catch (Exception e) {
            System.err.println("e");
        }
        return Conexion;
    }
            
    //contructor principal menu
    public VistaMenuPrincipal(UsuarioDAO vendedor) {
        
        
         
        initComponents();
        
        setTitle("Sesion de: " + vendedor.getNombre());
        setExtendedState(MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        
        if (vendedor.getId_tipo() ==1) {
            
        }else if(vendedor.getId_tipo()==2){
            jInventario.setVisible(false);
            jOpciones.setVisible(false);
        }
            
    }





    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenu4 = new javax.swing.JMenu();
        jMenuBar3 = new javax.swing.JMenuBar();
        jMenu5 = new javax.swing.JMenu();
        jMenu6 = new javax.swing.JMenu();
        jMenuBar4 = new javax.swing.JMenuBar();
        jMenu7 = new javax.swing.JMenu();
        jMenu8 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        labelLogo = new javax.swing.JLabel();
        pnMenuPrincipal = new javax.swing.JPanel();
        txtCodProducto = new javax.swing.JTextField();
        jTtotal = new javax.swing.JTextField();
        labelCodigoProductos = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        LabelNumeroVentas = new javax.swing.JLabel();
        lbIconoTienda = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaVentas = new javax.swing.JTable();
        btnPagar = new javax.swing.JButton();
        txcambio = new javax.swing.JTextField();
        lbsubtotalMenu = new javax.swing.JLabel();
        txtotal1 = new javax.swing.JTextField();
        lbEfecMenu = new javax.swing.JLabel();
        lbTotalApagarMENU = new javax.swing.JLabel();
        lbCambioMenu = new javax.swing.JLabel();
        txiva = new javax.swing.JTextField();
        txefectivo = new javax.swing.JTextField();
        lbIvaMenu = new javax.swing.JLabel();
        btnGestionarProducto = new javax.swing.JButton();
        btnProveedores = new javax.swing.JButton();
        btnFacturas = new javax.swing.JButton();
        btnClientes = new javax.swing.JButton();
        btnCerrar = new javax.swing.JButton();
        lbDerechoAutorMenu = new javax.swing.JLabel();
        btnbuscar = new javax.swing.JButton();
        jmenuMenuPrincipal = new javax.swing.JMenuBar();
        jOpciones = new javax.swing.JMenu();
        IteMenuVendedor = new javax.swing.JMenuItem();
        IteMenuConfiguracionOPcion = new javax.swing.JMenuItem();
        jMenu10 = new javax.swing.JMenu();
        jMenu1 = new javax.swing.JMenu();
        jInventario = new javax.swing.JMenu();
        IteMenuAbrinventarioMenu = new javax.swing.JMenuItem();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        jMenu2.setText("jMenu2");

        jMenuItem1.setText("jMenuItem1");

        jMenuItem2.setText("jMenuItem2");

        jMenu3.setText("File");
        jMenuBar2.add(jMenu3);

        jMenu4.setText("Edit");
        jMenuBar2.add(jMenu4);

        jMenu5.setText("File");
        jMenuBar3.add(jMenu5);

        jMenu6.setText("Edit");
        jMenuBar3.add(jMenu6);

        jMenu7.setText("File");
        jMenuBar4.add(jMenu7);

        jMenu8.setText("Edit");
        jMenuBar4.add(jMenu8);

        jMenuItem3.setText("jMenuItem3");

        labelLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/logoverdadero34 (2).png"))); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 204, 204));

        pnMenuPrincipal.setBackground(new java.awt.Color(102, 204, 255));
        pnMenuPrincipal.setForeground(new java.awt.Color(204, 204, 0));
        pnMenuPrincipal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtCodProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodProductoActionPerformed(evt);
            }
        });
        pnMenuPrincipal.add(txtCodProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 80, 190, 40));
        pnMenuPrincipal.add(jTtotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 470, 70, 30));

        labelCodigoProductos.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        labelCodigoProductos.setText("COD PRODUCTO");
        pnMenuPrincipal.add(labelCodigoProductos, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 90, 120, 20));
        pnMenuPrincipal.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(214, 35, 91, -1));

        LabelNumeroVentas.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        pnMenuPrincipal.add(LabelNumeroVentas, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 30, 80, -1));

        lbIconoTienda.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbIconoTienda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/logoverdadero34 (2).png"))); // NOI18N
        pnMenuPrincipal.add(lbIconoTienda, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 170, 150));

        tablaVentas.setBackground(new java.awt.Color(204, 204, 255));
        tablaVentas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 0, 0), new java.awt.Color(0, 204, 204), new java.awt.Color(0, 0, 0), new java.awt.Color(0, 0, 0)));
        tablaVentas.setForeground(new java.awt.Color(51, 51, 51));
        tablaVentas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CODIGO", "DESCRIPCION", "PRECIO", "CANTIDAD"
            }
        ));
        jScrollPane1.setViewportView(tablaVentas);

        pnMenuPrincipal.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 140, 840, 290));

        btnPagar.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnPagar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/signo-de-dolar (1).png"))); // NOI18N
        btnPagar.setText("PAGAR");
        btnPagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPagarActionPerformed(evt);
            }
        });
        pnMenuPrincipal.add(btnPagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 460, 120, 43));

        txcambio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txcambioActionPerformed(evt);
            }
        });
        pnMenuPrincipal.add(txcambio, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 520, 140, 50));

        lbsubtotalMenu.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbsubtotalMenu.setText("SUB TOTAL");
        pnMenuPrincipal.add(lbsubtotalMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 470, 110, 20));

        txtotal1.setFont(new java.awt.Font("Dialog", 1, 48)); // NOI18N
        txtotal1.setForeground(new java.awt.Color(0, 204, 102));
        pnMenuPrincipal.add(txtotal1, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 460, 230, 100));

        lbEfecMenu.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbEfecMenu.setText("      EFECTIVO");
        pnMenuPrincipal.add(lbEfecMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 470, 110, 20));

        lbTotalApagarMENU.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbTotalApagarMENU.setText("TOTAL APAGAR");
        pnMenuPrincipal.add(lbTotalApagarMENU, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 490, 120, 20));

        lbCambioMenu.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbCambioMenu.setText("CAMBIO");
        pnMenuPrincipal.add(lbCambioMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 540, 110, 20));

        txiva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txivaActionPerformed(evt);
            }
        });
        pnMenuPrincipal.add(txiva, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 500, 70, 30));

        txefectivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txefectivoActionPerformed(evt);
            }
        });
        pnMenuPrincipal.add(txefectivo, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 460, 140, 50));

        lbIvaMenu.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        lbIvaMenu.setText("          IVA");
        pnMenuPrincipal.add(lbIvaMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 500, 110, 20));

        btnGestionarProducto.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        btnGestionarProducto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/carrito-de-compras.png"))); // NOI18N
        btnGestionarProducto.setText("Registrar Producto");
        btnGestionarProducto.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnGestionarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGestionarProductoActionPerformed(evt);
            }
        });
        pnMenuPrincipal.add(btnGestionarProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 250, 50));

        btnProveedores.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        btnProveedores.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/provedore.png"))); // NOI18N
        btnProveedores.setText("Proveedores");
        btnProveedores.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnProveedores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProveedoresActionPerformed(evt);
            }
        });
        pnMenuPrincipal.add(btnProveedores, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, 250, -1));

        btnFacturas.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        btnFacturas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/facturas.png"))); // NOI18N
        btnFacturas.setText("Factura");
        btnFacturas.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnFacturas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFacturasActionPerformed(evt);
            }
        });
        pnMenuPrincipal.add(btnFacturas, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 250, 40));

        btnClientes.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        btnClientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/clasificacion.png"))); // NOI18N
        btnClientes.setText("Clientes");
        btnClientes.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClientesActionPerformed(evt);
            }
        });
        pnMenuPrincipal.add(btnClientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 250, 40));

        btnCerrar.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        btnCerrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/apagar.png"))); // NOI18N
        btnCerrar.setText("Cerrar");
        btnCerrar.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });
        pnMenuPrincipal.add(btnCerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, 250, 40));

        lbDerechoAutorMenu.setForeground(new java.awt.Color(255, 255, 255));
        lbDerechoAutorMenu.setText("© Todos los derechos 2022");
        pnMenuPrincipal.add(lbDerechoAutorMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 560, 170, 20));

        btnbuscar.setText("Buscar");
        btnbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbuscarActionPerformed(evt);
            }
        });
        pnMenuPrincipal.add(btnbuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 80, 90, 40));

        jOpciones.setText("OPCIONES");

        IteMenuVendedor.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        IteMenuVendedor.setText("Vendedores");
        IteMenuVendedor.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                IteMenuVendedorItemStateChanged(evt);
            }
        });
        IteMenuVendedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IteMenuVendedorActionPerformed(evt);
            }
        });
        jOpciones.add(IteMenuVendedor);

        IteMenuConfiguracionOPcion.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        IteMenuConfiguracionOPcion.setText("Configuracion");
        IteMenuConfiguracionOPcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IteMenuConfiguracionOPcionActionPerformed(evt);
            }
        });
        jOpciones.add(IteMenuConfiguracionOPcion);

        jmenuMenuPrincipal.add(jOpciones);
        jmenuMenuPrincipal.add(jMenu10);
        jmenuMenuPrincipal.add(jMenu1);

        jInventario.setText("INVENTARIO");

        IteMenuAbrinventarioMenu.setText("Abrir");
        IteMenuAbrinventarioMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IteMenuAbrinventarioMenuActionPerformed(evt);
            }
        });
        jInventario.add(IteMenuAbrinventarioMenu);

        jmenuMenuPrincipal.add(jInventario);

        setJMenuBar(jmenuMenuPrincipal);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnMenuPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnMenuPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPagarActionPerformed
      
    }//GEN-LAST:event_btnPagarActionPerformed

    private void txcambioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txcambioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txcambioActionPerformed

    private void txivaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txivaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txivaActionPerformed

    private void txefectivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txefectivoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txefectivoActionPerformed

    private void btnGestionarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGestionarProductoActionPerformed
        new VistaRegistrarProducto().setVisible(true);
    }//GEN-LAST:event_btnGestionarProductoActionPerformed

    private void btnProveedoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProveedoresActionPerformed
        new VistaProveedores().setVisible(true);
    }//GEN-LAST:event_btnProveedoresActionPerformed

    private void btnFacturasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFacturasActionPerformed
        new VistaFactura().setVisible(true);
    }//GEN-LAST:event_btnFacturasActionPerformed

    private void btnClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClientesActionPerformed
     new Cliente().setVisible(true);
    }//GEN-LAST:event_btnClientesActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed

      
        new CerrarSecion().setVisible(true);
    }//GEN-LAST:event_btnCerrarActionPerformed

    private void btnbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbuscarActionPerformed
     DefaultTableModel modeloTablaVentas =new DefaultTableModel();
     tablaVentas.setModel(modeloTablaVentas);
      
     String[] Titulo={"CODIGO","DESCRIPCION","PRECIO","CANTIDAD"};
     modeloTablaVentas = new DefaultTableModel(null, Titulo);
     tablaVentas.setModel(modeloTablaVentas);
     
     java.sql.Connection Conexion = null;
     String codigo = txtCodProducto.getText();
        try {
          
          PreparedStatement ps=Conexion.prepareStatement("SELECT codigo,nombre,precio,cantidad FROM Productos WHERE codigo = "+codigo);
          ResultSet rs=ps.executeQuery();
          
            if(rs.next()) {
                Object Fila[]=new Object[4];
                
                for (int i = 0; i < 4; i++) {
                    Fila[i]=rs.getObject(i+1);
                    
                    
                }
                modeloTablaVentas.addRow(Fila);
                
            }else{
                JOptionPane.showMessageDialog(null, "BUENO ");
            }
          Conexion.close();
          
        } catch (Exception e) {;
        }
             JOptionPane.showMessageDialog(null, "NO SE ENCONTRO ");
        
    }//GEN-LAST:event_btnbuscarActionPerformed

    private void txtCodProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodProductoActionPerformed

    private void IteMenuConfiguracionOPcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IteMenuConfiguracionOPcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IteMenuConfiguracionOPcionActionPerformed

    private void IteMenuVendedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IteMenuVendedorActionPerformed
        new Vendedore().setVisible(true);
    }//GEN-LAST:event_IteMenuVendedorActionPerformed

    private void IteMenuVendedorItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_IteMenuVendedorItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_IteMenuVendedorItemStateChanged

    private void IteMenuAbrinventarioMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IteMenuAbrinventarioMenuActionPerformed
        new  VistaInventarios().setVisible(true);
    }//GEN-LAST:event_IteMenuAbrinventarioMenuActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VistaMenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VistaMenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VistaMenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VistaMenuPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JMenuItem IteMenuAbrinventarioMenu;
    private javax.swing.JMenuItem IteMenuConfiguracionOPcion;
    public javax.swing.JMenuItem IteMenuVendedor;
    private javax.swing.JLabel LabelNumeroVentas;
    public javax.swing.JButton btnCerrar;
    public javax.swing.JButton btnClientes;
    public javax.swing.JButton btnFacturas;
    public javax.swing.JButton btnGestionarProducto;
    public javax.swing.JButton btnPagar;
    public javax.swing.JButton btnProveedores;
    public javax.swing.JButton btnbuscar;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    public javax.swing.JMenu jInventario;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu10;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuBar jMenuBar3;
    private javax.swing.JMenuBar jMenuBar4;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    public javax.swing.JMenu jOpciones;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JTextField jTtotal;
    private javax.swing.JMenuBar jmenuMenuPrincipal;
    public javax.swing.JLabel labelCodigoProductos;
    private javax.swing.JLabel labelLogo;
    public javax.swing.JLabel lbCambioMenu;
    public javax.swing.JLabel lbDerechoAutorMenu;
    public javax.swing.JLabel lbEfecMenu;
    public javax.swing.JLabel lbIconoTienda;
    public javax.swing.JLabel lbIvaMenu;
    public javax.swing.JLabel lbTotalApagarMENU;
    public javax.swing.JLabel lbsubtotalMenu;
    private javax.swing.JPanel pnMenuPrincipal;
    public javax.swing.JTable tablaVentas;
    public javax.swing.JTextField txcambio;
    public javax.swing.JTextField txefectivo;
    public javax.swing.JTextField txiva;
    public javax.swing.JTextField txtCodProducto;
    public javax.swing.JTextField txtotal1;
    // End of variables declaration//GEN-END:variables

    private static class bufferredimagen {

        public bufferredimagen() {
        }
    }
}

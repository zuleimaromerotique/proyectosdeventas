
package vista;

import java.awt.event.KeyEvent;

public class VistaLogin extends javax.swing.JFrame {

    public VistaLogin() {
        initComponents();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }



    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbIniciar = new javax.swing.JPanel();
        lblogueo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        txtContraseña = new javax.swing.JPasswordField();
        btnIngresar = new javax.swing.JButton();
        lbiconoTienda = new javax.swing.JLabel();
        lbTituloIniociarSecion = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lbUsuario = new javax.swing.JLabel();
        labelUsuarioContraseñaIncorrecta = new javax.swing.JLabel();
        lbIconoContraseña = new javax.swing.JLabel();
        btnCambiarContraseña = new java.awt.Button();
        jLabel2 = new javax.swing.JLabel();
        lbTituloIniociarSecion1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lbIniciar.setBackground(new java.awt.Color(102, 204, 255));
        lbIniciar.setForeground(new java.awt.Color(153, 255, 255));

        lblogueo.setBackground(new java.awt.Color(255, 255, 255));
        lblogueo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblogueo.setForeground(new java.awt.Color(0, 0, 0));
        lblogueo.setCursor(new java.awt.Cursor(java.awt.Cursor.CROSSHAIR_CURSOR));
        lblogueo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        lblogueo.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(348, 105, 41, -1));

        txtUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsuarioActionPerformed(evt);
            }
        });
        txtUsuario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtUsuarioKeyPressed(evt);
            }
        });
        lblogueo.add(txtUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 290, 221, 33));

        txtContraseña.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtContraseñaKeyPressed(evt);
            }
        });
        lblogueo.add(txtContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 380, 221, 30));

        btnIngresar.setText("INGRESAR");
        btnIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarActionPerformed(evt);
            }
        });
        btnIngresar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnIngresarKeyPressed(evt);
            }
        });
        lblogueo.add(btnIngresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 450, 221, 39));

        lbiconoTienda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/DXJOSPJCFJA.png"))); // NOI18N
        lbiconoTienda.setText("jLabel3");
        lblogueo.add(lbiconoTienda, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 80, 174, -1));

        lbTituloIniociarSecion.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        lbTituloIniociarSecion.setForeground(new java.awt.Color(0, 0, 0));
        lbTituloIniociarSecion.setText("                                INICIAR SECION");
        lbTituloIniociarSecion.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblogueo.add(lbTituloIniociarSecion, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 380, 50));
        lblogueo.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 310, -1, -1));

        lbUsuario.setBackground(new java.awt.Color(51, 51, 51));
        lbUsuario.setForeground(new java.awt.Color(51, 51, 51));
        lbUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/account_avatar_face_man_people_profile_user_icon_123197.png"))); // NOI18N
        lbUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.CROSSHAIR_CURSOR));
        lblogueo.add(lbUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 290, 30, 30));

        labelUsuarioContraseñaIncorrecta.setForeground(new java.awt.Color(255, 0, 0));
        lblogueo.add(labelUsuarioContraseñaIncorrecta, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 430, 210, 20));

        lbIconoContraseña.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/contraseña.png"))); // NOI18N
        lblogueo.add(lbIconoContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 380, 30, -1));

        btnCambiarContraseña.setActionCommand("Cambiar Contraseña");
        btnCambiarContraseña.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnCambiarContraseña.setLabel("Cambiar Contraseña");
        btnCambiarContraseña.setName("Cambiar Contraseña"); // NOI18N
        btnCambiarContraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCambiarContraseñaActionPerformed(evt);
            }
        });
        lblogueo.add(btnCambiarContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 500, -1, -1));
        btnCambiarContraseña.getAccessibleContext().setAccessibleName("");

        jLabel2.setText("jLabel2");

        lbTituloIniociarSecion1.setFont(new java.awt.Font("Dialog", 1, 12)); // NOI18N
        lbTituloIniociarSecion1.setForeground(new java.awt.Color(0, 0, 0));
        lbTituloIniociarSecion1.setText("      © Todos los Derechos Reservados 2022");
        lbTituloIniociarSecion1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout lbIniciarLayout = new javax.swing.GroupLayout(lbIniciar);
        lbIniciar.setLayout(lbIniciarLayout);
        lbIniciarLayout.setHorizontalGroup(
            lbIniciarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lbIniciarLayout.createSequentialGroup()
                .addGroup(lbIniciarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(lbIniciarLayout.createSequentialGroup()
                        .addGap(425, 425, 425)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(lbIniciarLayout.createSequentialGroup()
                        .addGap(337, 337, 337)
                        .addComponent(lblogueo, javax.swing.GroupLayout.PREFERRED_SIZE, 456, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(lbIniciarLayout.createSequentialGroup()
                        .addGap(372, 372, 372)
                        .addComponent(lbTituloIniociarSecion1, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(344, Short.MAX_VALUE))
        );
        lbIniciarLayout.setVerticalGroup(
            lbIniciarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lbIniciarLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(lblogueo, javax.swing.GroupLayout.PREFERRED_SIZE, 529, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(lbTituloIniociarSecion1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(67, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(lbIniciar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbIniciar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUsuarioActionPerformed
 //Instruccion para posicionar la caja validarusuario
    private void btnIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarActionPerformed
      controlador.controlLogin.ValidaUsuario();
    }//GEN-LAST:event_btnIngresarActionPerformed

    private void btnCambiarContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCambiarContraseñaActionPerformed
        new Cambiacontraseña().setVisible(true);
    }//GEN-LAST:event_btnCambiarContraseñaActionPerformed

    private void btnIngresarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnIngresarKeyPressed
      
    }//GEN-LAST:event_btnIngresarKeyPressed

    private void txtContraseñaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtContraseñaKeyPressed
        if (evt.getKeyCode()== KeyEvent.VK_ENTER) {
            controlador.controlLogin.ValidaUsuario();
        }
    }//GEN-LAST:event_txtContraseñaKeyPressed

    //instruccion para poder posicionar en la caja de texto contraseña

    private void txtUsuarioKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtUsuarioKeyPressed
       if (evt.getKeyCode()== KeyEvent.VK_ENTER) {
            txtContraseña.requestFocus();
        }
    }//GEN-LAST:event_txtUsuarioKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VistaLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button btnCambiarContraseña;
    public javax.swing.JButton btnIngresar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    public javax.swing.JLabel labelUsuarioContraseñaIncorrecta;
    private javax.swing.JLabel lbIconoContraseña;
    private javax.swing.JPanel lbIniciar;
    private javax.swing.JLabel lbTituloIniociarSecion;
    private javax.swing.JLabel lbTituloIniociarSecion1;
    public javax.swing.JLabel lbUsuario;
    private javax.swing.JLabel lbiconoTienda;
    private javax.swing.JPanel lblogueo;
    public javax.swing.JPasswordField txtContraseña;
    public javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}

